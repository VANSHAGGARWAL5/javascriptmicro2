import { Item } from "../models/itemModel.js";

export const createItem = async (req, res) => {
  try {
    const item = await Item.create(req.body);
    res.status(201).json({ message: "Item created", item });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};
